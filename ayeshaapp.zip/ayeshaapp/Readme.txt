Batch : IAJS - 2202
Mentor: Jahangir Alam Talukder (Rony Talukder)
Team : B 

Project : Mobile App Lainding page 
Project Tittle : Ayesha App

Use Technology : HTML, CSS,JAVASCRIPT, JQUERY, BOOTSTRAP

Jquery Plugins : 
                => slick slider
		=> aos.js 
		=> font awesome
		=> counter js
		=> type js



Team Member :
	 => Mohammad Anisur Rahman
	 => Md All Mohib
	 => Tahmid Hasan Siam
	 => Mahin Mahabullah
	 => Md Nowsad
	 => Md fazlyrabbi
	 => Md Mustafizur Rahman Rajon
	 => Mahfuz Ahmed
	 => Bilkis
	 => Nusrat Nira
	 => Tabassom Jahan Orpa
	 => Shahadad Hossen Imran
	 => Omor faruk




 