


$('.my_slider_2').slick({

    centerMode: true,
    centerPadding: '0',
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 2,
    arrows:true,
    autoplay:true,
    prevArrow:' <span class="prev_arrows"><i class="fa-solid fa-circle-arrow-left"></i></span>', 
    nextArrow:' <span class="next_arrows"><i class="fa-solid fa-circle-arrow-right"></i></span>',
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
         
          
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
  
      
    ]
    
  });
$('.my_slider_5').slick({

    centerMode: true,
    centerPadding: '0',
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 2,
    slidesToScroll: 1,
    arrows:true,
    autoplay:true,
    prevArrow:' <span class="prev_arrows"><i class="fa-solid fa-circle-arrow-left"></i></span>', 
    nextArrow:' <span class="next_arrows"><i class="fa-solid fa-circle-arrow-right"></i></span>',
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
         
          
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
  
      
    ]
    
  });
$('.my_slider_3').slick({

    centerMode: true,
    centerPadding: '0',
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows:true,
    autoplay:true,
    prevArrow:' <span class="prev_arrows"><i class="fa-solid fa-circle-arrow-left"></i></span>', 
    nextArrow:' <span class="next_arrows"><i class="fa-solid fa-circle-arrow-right"></i></span>',
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
         
          
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
  
      
    ]
  });
$('.my_slider_4').slick({

    centerMode: true,
    centerPadding: '0',
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows:true,
    autoplay:true,
    prevArrow:' <span class="prev_arrows"><i class="fa-solid fa-circle-arrow-left"></i></span>', 
    nextArrow:' <span class="next_arrows"><i class="fa-solid fa-circle-arrow-right"></i></span>',
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
         
          
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
  
      
    ]
   
    
  });
$('.my_slider_1').slick({

    centerMode: true,
    centerPadding: '0',
    dots: false,
    infinite: true,
    speed: 700,
    slidesToShow: 6,
    slidesToScroll: 1,
    arrows:true,
    autoplay:true,
    prevArrow:' <span class="prev_arrows"><i class="fa-solid fa-circle-arrow-left"></i></span>', 
    nextArrow:' <span class="next_arrows"><i class="fa-solid fa-circle-arrow-right"></i></span>',
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
         
          
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
  
      
    ]
  });
  let btn = document.getElementById('btn')
let btn1 = document.getElementById('btn1')

let snumber = document.getElementById('snumber')
let unumber = document.getElementById('unumber')
let pnumber = document.getElementById('pnumber')

btn1.addEventListener('click',function(){
  snumber.innerText = '33'
  unumber.innerText = '99'
  pnumber.innerText = '55'
})


btn.addEventListener('click',function(){
  snumber.innerText = '396'
  unumber.innerText = '700'
  pnumber.innerText = '900'
})
$('.counter').counterUp({
  delay: 2,
  time: 1000
});

 